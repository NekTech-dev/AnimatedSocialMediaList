document.onscroll = function(){
    if(window.innerHeight+window.scrollY>=document.body.clientHeight){
        document.querySelector(".social-media").classList.remove('showMedia');
        document.querySelector(".social-media").classList.add('hideMedia');
    }else{
        document.querySelector(".social-media").classList.remove('hideMedia');
        document.querySelector(".social-media").classList.add('showMedia');
    }
}